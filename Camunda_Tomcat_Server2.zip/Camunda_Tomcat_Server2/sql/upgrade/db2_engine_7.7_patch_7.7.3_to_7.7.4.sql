-- insert startup.lock in property table - https://app.camunda.com/jira/browse/CAM-8162  --
insert into ACT_GE_PROPERTY
values ('startup.lock', '0', 1);