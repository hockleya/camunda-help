window.camWelcomeConf = {
  // app: {
  //   name: 'Todos',
  //   vendor: 'Company'
  // },
  //
  // configure the date format
  // "dateFormat": {
  //   "normal": "LLL",
  //   "long":   "LLLL"
  // },
  //
  // "locales": {
  //    "availableLocales": ["en", "de"],
  //    "fallbackLocale": "en"
  //  },
  // links: [
  //   {
  //     label: 'Angular.js Docs',
  //     href: 'https://code.angularjs.org/1.2.16/docs',
  //     description: 'Almost interesting'
  //   },
  //   {
  //     label: 'XKCD',
  //     href: 'http://xkcd.org',
  //     description: 'Nerdy comic'
  //   },
  //   {
  //     label: 'Slashdot',
  //     href: 'https://slashdot.org',
  //     description: 'News for nerds, stuff that matter'
  //   }
  // ]
};
